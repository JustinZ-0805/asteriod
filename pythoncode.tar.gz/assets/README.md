# Asteroids Enemy Patrol

This is a Python/Pygame game that is meant to be packaged with `pygbag` for browser deployment.

## Install dependencies

```bash
pip install -r requirements.txt
```

## Run locally in Python

```bash
python main.py
```

## Build for the web with pygbag

From the project folder, run:

```bash
pygbag main.py
```

This creates a web build that can be hosted on GitHub Pages.

## Publish to GitHub Pages

1. Push the project to GitHub.
2. Open the repository in GitHub.
3. Go to Settings → Pages.
4. Set the source to the branch/folder that contains the generated pygbag build.
5. Save.

Your site will be published at:

```text
https://<your-username>.github.io/<your-repository>/
```

> This is the correct approach for a Pygame game on GitHub Pages. Pygbag compiles the Python game into a browser-friendly build.
